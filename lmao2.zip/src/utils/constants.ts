const Constants = {
  GITHUB_URL: 'https://github.com/kikorp78',
  DISCORD_URL: 'https://discord.com/users/768391556964024330'
} as const;

export default Constants;
