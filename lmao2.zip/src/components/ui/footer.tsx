import Constants from '@/utils/constants';
import { IconBrandDiscord, IconBrandGithub } from '@tabler/icons-react';

import Image from 'next/image';
import Link from 'next/link';
import { FC } from 'react';

const Footer: FC = () => {
  return (
    <div className="flex justify-between items-center space-x-3 border-t border-neutral-100 py-5">
      <p className="text-opacity-80 text-neutral-300 text-paragraph-xs font-medium">
        &copy; kikorp.dev &mdash; 2024, All Rights Reserved
      </p>
      <div className="flex items-center space-x-5">
        <div className="hidden sm:flex items-center space-x-2">
          <Image
            className="w-4 h-4"
            src="/nextjs.svg"
            width={0}
            height={0}
            sizes="100vw"
            alt="Next.js Logo"
            priority
          />
          <p className="text-opacity-80 text-neutral-300 text-paragraph-xs font-medium">
            Built with Next.js
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Link
            className="group"
            href={Constants.GITHUB_URL}
            target="_blank"
            rel="noopener,noreferrer"
          >
            <IconBrandGithub className="text-opacity-80 group-hover:text-opacity-100 text-neutral-300 transition" />
          </Link>
          <Link
            className="group"
            href={Constants.DISCORD_URL}
            target="_blank"
            rel="noopener,noreferrer"
          >
            <IconBrandDiscord className="text-opacity-80 group-hover:text-opacity-100 text-neutral-300 transition" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Footer;
