import { IconExternalLink } from '@tabler/icons-react';

import Link from 'next/link';
import { FC, ReactElement, cloneElement } from 'react';

interface Props {
  content: string;
  icon: ReactElement;
  url?: string;
}

const ProjectTag: FC<Props> = ({ content, icon, url }) => {
  return (
    <div className="flex items-center space-x-[6px]">
      {cloneElement(icon, { className: 'text-opacity-80 text-neutral-300' })}
      {url ? (
        <div className="group flex items-center space-x-[6px]">
          <Link
            className="text-opacity-80 group-hover:text-opacity-100 text-neutral-300 text-paragraph-xs font-medium transition"
            href={url}
            target="_blank"
            rel="noopener,noreferrer"
          >
            {content}
          </Link>
          <IconExternalLink
            className="text-opacity-80 group-hover:text-opacity-100 text-neutral-300 transition"
            size={16}
          />
        </div>
      ) : (
        <p className="text-opacity-80 text-neutral-300 text-paragraph-xs font-medium">
          {content}
        </p>
      )}
    </div>
  );
};

export default ProjectTag;
